const COLORS = {
  blue:'#026ece',
  green: '#00b3a1',
  red:'#dd4b59'
  // your colors
};
export default COLORS;
